insert into course(id,name) values(101,'JPA');
insert into course(id,name) values(102,'JDBC');
insert into course(id,name) values(103,'SPRING');
insert into course(id,name) values(104,'BOOT');